from django import forms
from modelos.usuario.models import Usuario
from django.contrib.auth.forms import User, UserCreationForm

class UsuarioForm(forms.ModelForm):

	class Meta:
		model = Usuario

		fields = [
			'numero_documento', 
			'tipo_documento',
			'nombre',
			'appellido',
			'telefono',
			#'correo',
			'fecha_nacimiento',
			'direccion',
			'ciudad',
			'genero',
			'eps',
			
			
		]
		labels = {
			'numero_documento': 'Numero Documento',
			'tipo_documento':'Tipo Documento',
			'nombre':'Nombre',
			'appellido':'Apellido',
			'telefono':'Telefono',
			#'correo':'Correo',
			'fecha_nacimiento':'Fecha Nacimiento',
			'direccion':'Direccion',
			'ciudad':'Ciudad',
			'genero':'Genero',
			'eps_usuario':'EPS',
			
		}
		widgets = {
			'numero_documento':forms.TextInput(attrs={'class':'form-control', 'id':'cedula', 'placeholder':'Numero de Cedula', 'type':'TextInput', 'requerid':''}),
			'tipo_documento':forms.TextInput(attrs={'class':'form-control', 'id':'tipo_documento', 'placeholder':'Tipo de Documento', 'type':'TextInput', 'requerid':'' }),
			'nombre':forms.TextInput(attrs={'class':'form-control', 'id':'nombre', 'placeholder':'Nombre', 'type':'TextInput','requerid':''}),
			'appellido':forms.TextInput(attrs={'class':'form-control', 'id':'apellidos', 'placeholder':'Apellidos', 'type':'TextInput', 'requerid':''}),
			'telefono':forms.TextInput(attrs={'class':'form-control', 'id':'telefono', 'placeholder':'Telefono', 'type':'TextInput', 'requerid':''}),
			#'correo':forms.EmailInput(attrs={'class':'form-control'}),
			'fecha_nacimiento':forms.TextInput(attrs={'class':'form-control', 'type':'date'}),
			'direccion':forms.TextInput(attrs={'class':'form-control', 'id':'direccion', 'placeholder':'Direccion', 'type':'TextInput', 'requerid':''}),
			'ciudad':forms.Select(attrs={'class':'form-control'}),
			'genero':forms.Select(attrs={'class':'form-control'}),
			'eps':forms.Select(attrs={'class':'form-control'}),
			
			
		}

class UserForm(UserCreationForm):
	
	class Meta:
		model = User 
		fields = [
			'username',
			#'first_name',
			#'last_name',
			'email',
			#'password',
			
		]
		labels = {
			'username':'Numero de Identificacion',
			#'first_name':'Nombre',
			#'last_name':'Apellidos',
			'email':'Correo',
			#'password':'password',
		}		

		widgets = {
			'username':forms.TextInput(attrs={'class':'form-control', 'id':'cedula', 'placeholder':'Numero de Cedula', 'type':'TextInput', 'requerid':''}),
			'email':forms.EmailInput(attrs={'class':'form-control', 'id':'correo', 'placeholder':'Correo', 'type':'TextInput', 'requerid':''}),
			#'password':forms.PasswordInput(attrs={'class':'form-control'})
		
					
		}

	
	
		



