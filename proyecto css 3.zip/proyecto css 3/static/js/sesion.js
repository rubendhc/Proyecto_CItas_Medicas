

$(document).ready(function(){

// para clases ".clase" "#id"  "h2, p, label, a"
// Evento click del boton


$('#selectID').change(function() {
	var optionID = $('option:selected').attr('id');

	$('#result').html(optionID);

	if(optionID=='btnRestablecer'){
		$("h2,label,a").css("color", "#2874A6");
		$(".login-button").css("background-color", "#2874A6" );
		$(".registrar").css("background-color", "#2874A6");
		$(".lista").css("color", "black");
		$(".login").css("background", "rgba(0,0,0,0.1)");
		$("body").css("color", "#46485c");

	}
	if(optionID=='btnNegro'){
		$("h2,label,a").css("color", "#000000");
		$(".login-button").css("background-color", "#000000" );
		$(".registrar").css("background-color", "#000000");
		$(".lista").css("color", "#000000");
		$(".login").css("background", "rgba(0,0,0,0.1)");
	}
	if(optionID=='btnGris'){
		$("h2,label,a").css("color", "#535362");
		$(".login-button").css("background-color", "#535362" );
		$(".registrar").css("background-color", "#535362");
		$(".lista").css("color", "#535362");
		$(".login").css("background", "rgba(0,0,0,0.1)");
	}
	if(optionID=='btnAzul'){
		$("h2,label,a").css("color", "#0080FF");
		$(".login-button").css("background-color", "#0080FF" );
		$(".registrar").css("background-color", "#0080FF");
		$(".lista").css("color", "#0080FF");
		$(".login").css("background", "rgba(0,0,0,0.1)");
	}
	if(optionID=='btnVerde'){

		$("h2,label,a").css("color", "#00B200");
		$(".login-button").css("background-color", "#00B200" );
		$(".registrar").css("background-color", "#00B200");
		$(".lista").css("color", "#00B200");
		$(".login").css("background", "rgba(0,0,0,0.1)");
	}
	if(optionID=='btnRojo'){

		$("h2,label,a").css("color", "#FF0000");
		$(".login-button").css("background-color", "#FF0000" );
		$(".registrar").css("background-color", "#FF0000");
		$(".lista").css("color", "#FF0000");
		$(".login").css("background-color", "#f5f5f5");
	}
	if(optionID=='btnAmarillo'){

		$("h2,label,a").css("color", "#FFFF00");
		$(".login-button").css("background-color", "#FFFF00" );
		$(".registrar").css("background-color", "#FFFF00");
		$(".lista").css("color", "#FFFF00");
		$(".login").css("background", "rgba(0,0,0,0.1)");
	}
	if(optionID=='btnNaranja'){

		$("h2,label,a").css("color", "#FF7F00");
		$(".login-button").css("background-color", "#FF7F00" );
		$(".registrar").css("background-color", "#FF7F00");
		$(".lista").css("color", "#FF7F00");
		$(".login").css("background", "rgba(0,0,0,0.1)");
	}
	if(optionID=='btnVioleta'){

		$("h2,label,a").css("color", "#7F00FF");
		$(".login-button").css("background-color", "#7F00FF" );
		$(".registrar").css("background-color", "#7F00FF");
		$(".lista").css("color", "#7F00FF");
		$(".login").css("background", "rgba(0,0,0,0.1)");
	}
});
/*
$("#btnNegro").click(function(){
 
 	$("h2,label,a").css("color", "#000000");
 	$(".login-button").css("background-color", "#000000" );
 	$(".registrar").css("background-color", "#000000");
 	$(".login").css("background-color", "#f5f5f5");
  
});


$("#btnAzul").click(function(){
  
 	$("h2,label,a").css("color", "#2874A6");
	$(".login-button").css("background-color", "#2874A6" );
 	$(".registrar").css("background-color", "#2874A6");
 	$(".login").css("background-color", "rgba(0,0,0,0.1)");

});

$("#btnVerde").click(function(){
  
 	$("h2,label,a").css("color", "#008C8C");
	$(".login-button").css("background-color", "#008C8C" );
 	$(".registrar").css("background-color", "#008C8C");
 	$(".login").css("background-color", "f2f2f2");

});


*/

});

