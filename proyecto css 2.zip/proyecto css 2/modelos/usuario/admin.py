# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from modelos.usuario.models import Usuario
# Register your models here.
admin.site.register(Usuario)
